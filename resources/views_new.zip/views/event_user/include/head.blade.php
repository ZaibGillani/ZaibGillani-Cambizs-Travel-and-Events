<head>
	<!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="csrf-token" content="{{ csrf_token() }}">
      <!--favicon-->
      <link rel="icon" href="assets/images/favicon.ico" />
        {{-- Styles --}}
      <!--== Google Fonts ==-->
      <link href="https://fonts.googleapis.com/css?family=Poppins:400,400i,500,600,700,800" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,500i,700,700i" rel="stylesheet">
      <!--== Bootstrap CSS ==-->
      <link href="{{ url('public/css/event_user/plugins/perfect-scrollbar/css/perfect-scrollbar.css') }}" rel="stylesheet"/>
      <!--== Icofont CSS ==-->
      <link href="{{ url('public/css/event_user/pace.min.css') }}" rel="stylesheet"/>
      <!--== ElegantIcons CSS ==-->
      <link href="{{ url('public/css/event_user/bootstrap.min.css') }}" rel="stylesheet"/>
      <!--== Animate CSS ==-->
      <link href="{{ url('public/css/event_user/app.css') }}" rel="stylesheet"/>
	  <link href="{{ url('/css/app1.css') }}" rel="stylesheet"/>
      <!--== Aos CSS ==-->
      <link href="{{ url('public/css/event_user/icons.css') }}" rel="stylesheet"/>
	   <script src="{{ url('/js/jquery-3.5.1.min.js') }}"></script>
	  <style>
		.footer-area{
			display:none;
		}
	  </style>
    
</head>