<?php

namespace App\Http\Controllers;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Models\Event;
use Illuminate\Support\Facades\DB;
use Hash;
use Stripe;
  
class PaymentController extends Controller {
	
	public function stripe() {
        return view('stripe');
    }
	
	public function payment_form(Request $request){		
		$req = $request->all();
		return view('payment_form/stripe',['ticket_details' => $req]);
	}
	
	
	public function stripe_test(){
		
		Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
		
		/* $customer = Stripe\Customer::create([
		  'description' => 'My First Test Customer (created for API docs)',
		  'email'=>"abc@gmail.com"
		]); */
		
	  	$account = Stripe\Account::create([
		  'type' => 'custom',
		  'country' => 'US',
		  'email' => 'abc@gmail.com',
		  'capabilities' => [
			'card_payments' => ['requested' => true],
			'transfers' => ['requested' => true],		
		  ],
		  'business_type' => 'individual',
		  'business_profile' => [
    		    # Industry: Software 
    		    'mcc' => '5734',
    		    'name' => '5734',
    		    'support_email' => 'abc@gmail.com',
    		    'support_phone' => '9041345002',
    		    'product_description' => "testing",
    		    
    		 ],
			'individual' => [	
    			'address' => [
    			    'city' => 'test',
    				'line1' => 'test',
    				'line2' => 'test',
    				'postal_code' => '99950',
    				'state' => 'Alaska',
    			],
    			
    			'first_name' => 'test',
    			'last_name' => ' ',
    			'dob' => [
    				'day'	=> '12',
    				'month'	=> '09',
    				'year'	=> '1989',
    			],			
    			'id_number' => '111111111',
    			'email' => 'ttt@gmail.com',
    			'phone' => '9041345002',
    		],
			'tos_acceptance' => [
    			'date' => time(),
    			'ip' => $_SERVER['REMOTE_ADDR'],
    		],
    		'external_account' => [
    			"object" =>  "bank_account",
    			"country" =>  "US",
    			"currency" =>  "usd",
    			'account_number' => '000123456789',
    			"account_holder_name" =>  'test',
    			"account_holder_type" =>  'individual',
    			"bank_name" =>  'test bank',
    			"routing_number" =>  '110000000',
    		],
		]);
		
		
		/* $account =  $stripe->accounts->update(
		  'acct_1KiM9YQ24GsuFai8',
		  'capabilities' => [
			'card_payments' => ['requested' => true],
		  ]
		); */
		
/* 	 	$paymentIntent = \Stripe\PaymentIntent::create([
		  'amount' => 10000,
		  'currency' => 'usd',
		  'payment_method_types' => ['card'],
		  'transfer_group' => '{ORDER10}',
		]);*/

		// Create a Transfer to a connected account (later):
		/* $transfer = \Stripe\Transfer::create([
		  'amount' => 7000,
		  'currency' => 'usd',
		  'destination' => 'acct_1KiM9YQ24GsuFai8',
		  'transfer_group' => '{ORDER10}',
		]); */
 	
		/* echo"<pre>";
		print_r($account);
		die; */
		//sam: acct_1KjppEQRdUPNTxGy
		$stripe_veri = Stripe\AccountLink::Create([
			'account' => 'acct_1KjpugG39qm20xPR',
			'refresh_url' => 'https://example.com/reauth',
			'return_url' => 'https://example.com/return',
			'type' => 'account_onboarding',
			'collect' => 'eventually_due']);
		/* $stripe->accountLinks->create(
		  [
			'account' => 'acct_1KjppEQRdUPNTxGy',
			'refresh_url' => 'https://example.com/reauth',
			'return_url' => 'https://example.com/return',
			'type' => 'account_onboarding',
			'collect' => 'eventually_due',
		  ]
		); */
		echo"<pre>";
		print_r($stripe_veri);
		die;
	}
	
	public function payment_process(Request $request){
		$req = $request->all();
		
		$ticket_price = $req['ticket_price'];
		$ticket_type = $req['ticket_type'];
		$ticket_id = $req['ticket_id'];
		
		$new_value=array();
		$select_ticket = DB::table('events_table')
			->where('id','=',$ticket_id)
            ->get();
		echo"<pre>";
		print_r($select_ticket);
		die;
		/* foreach($select_ticket as $slct_tic) {
			$ticket_details = $slct_tic->ticket_details;
			$ticket_details_ary = json_decode($ticket_details, TRUE);
			foreach($ticket_details_ary as $ticket_det){
				$ticket_total = $ticket_det['total_tickets'];
				if($ticket_type==$ticket_det['ticket_name']){
					echo $ticket_total = $ticket_det['total_tickets']-1;
					
				}
				$new_value[] = array("ticket_name"=>$ticket_det['ticket_name'],"price"=>$ticket_det['total_tickets'],"total_tickets"=>$ticket_total);
			}
		}		
		//$ticket_details_ary = json_decode($ticket_details, TRUE);
		$ticket_details_ary_new = json_encode($new_value, TRUE);

		$update = DB::table('events_table')
                ->where('id', $ticket_id)
                ->update(['ticket_details' => $ticket_details_ary_new]); */
				
		Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        $strip_n = Stripe\Charge::create ([
                "amount" => 100 * 100,
                "currency" => "usd",
				"source" => $request->stripeToken,
                "description" => "Test payment from itsolutionstuff.com." 
        ]);
		
		echo"<pre>";
		print_r($strip_n);
		die;
		
	}
	
}