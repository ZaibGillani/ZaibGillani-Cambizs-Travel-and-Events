<?php

namespace App\Http\Controllers;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\CursorPaginator;
use Hash;
  
class AuthController extends Controller
{
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function index()
    {
        return view('auth.login');
    }  
      
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function registration()
    {
        return view('auth.registration');
    }
      
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function postLogin(Request $request)
    {
		
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
		
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
			
			$response = array('message' => 'success');
			
            return redirect()->intended('after_login')
                       ->withSuccess('You have Successfully loggedin');
        }
	
		if(!Auth::check()){
			
				$response = array(
					'status' => false,
					'message' => 'fail',
				);
				echo json_encode( $response );
				die;
			
		}
		
  /*  echo"<pre>";
   echo".....";
		print_r($_REQUEST);
		die; */
       // return redirect("login")->withSuccess('Oppes! You have entered invalid credentials');
    }
      
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function postRegistration(Request $request)
    {  
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
        ]);
           
        $data = $request->all();
		
        $check = $this->create($data);
         
        return redirect("dashboard")->withSuccess('Great! You have Successfully loggedin');
    }
    
    /**
     * Write code on Method
     *
     * @return response()
     */
	 
	public function after_login()
    {
		$data = session()->all();
        if(Auth::check()){
			$id = Auth::user()->id;
			$user_role = Auth::user()->role;
			
			if($id!=''){
				$response = array(
					'status' => true,
					'message' => 'success',
					'role'=>$user_role
				);
				echo json_encode( $response );
				//dir;
				//return redirect("dashboard")->withSuccess('Great! You have Successfully loggedin');
				die;
			}
			         
        }
  
        return redirect("login")->withSuccess('Opps! You do not have access');
    }
	
	public function user_update(Request $request){
		$params = request()->all();
		
		$user = Auth::user();
		
		$id = Auth::user()->id;
		
		$data = $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
        ]);

        $user->name = $data['name'];
        $user->email = $data['email'];

        $user->save();
        return redirect('/dashboard/setting/'.Auth::user()->id)->with('success', 'User has been updated!!');
		
	}
	
	public function add_bank(){
		return view('event_user/bankdetails');
		//return view('event_user/bankdetails', []);
	}
	
	public function admin_payout(){
		return view('admin/admin_payout');
	}
	
	public function confirm_payment(){
		return view('admin/confirm_payment');
	}
	
    public function dashboard()
    {
		$data = session()->all();
        if(Auth::check()){
			$id = Auth::user()->id;
			$role = Auth::user()->role;
			
			if($id!=''){
				$response = array(
					'status' => true,
					'message' => 'success',
				);

			}
			if($role=="role_event"){
				$event_data = DB::table('events_table')->orderBy('id',"DESC")->where('user_id', $id)->cursorPaginate(10);
				
				return view('event_user/dashboard', ['event_data' => $event_data,"user_id"=>$id]);
			}           
        }
  
        return redirect("login")->withSuccess('Opps! You do not have access');
    }
    
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function create(array $data)
    {
		
		$id =  User::create([
			'name' => $data['name'],
			'email' => $data['email'],
			'role' => $data['role'],
			'password' => Hash::make($data['password'])
		])->id;

		if($id!=''){
		$response = array(
			'status' => true,
			'message' => 'success',
		);
		echo json_encode( $response );
		//return view('event_user/dashboard', ['event_data' => $event_data,"user_id"=>$id]);
		die;
		}
	  
    }
    
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function logout() {
        Session::flush();
        Auth::logout();
  
        return Redirect('/');
    }
	
	public function event_backend() {
		echo"this is test";
	}
}